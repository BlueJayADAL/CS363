<?php
 #header("Access-Control-Allow-Origin: http://www.bank33.com");

 echo "Time from Bank99: ".date("h:i:sa")
?>



