<!doctype html>
<html>
<body>

<h1>PHP Example: Inline</h1>

<h2>Current time is 
<?php echo date("Y-m-d h:i:sa") ?>
</h2>

</body>
</html>
