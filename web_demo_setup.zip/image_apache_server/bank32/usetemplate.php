<?php
 $title = "PHP Example: Template";
 $time = date("Y-m-d h:i:sa") 
?>

<!doctype html>
<html>
<body>
<h1><?=$title?></h1>
<h2>Current time is <?=$time?></h2>
</body>
</html>
