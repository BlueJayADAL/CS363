<?php
 #header("Access-Control-Allow-Origin: http://www.bank99.com");

 echo "Time from Bank32: ".date("h:i:sa")
?>



