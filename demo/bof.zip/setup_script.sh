#!/bin/bash
# Lab setup script based on CS363 lecture slides (Page 20, 23, 29)

echo "--- Disabling ASLR (Address Space Layout Randomization) ---"
# This requires sudo privileges
sudo sysctl -w kernel.randomize_va_space=0

echo "--- Compiling vulnerable program (stack) ---"
# -fno-stack-protector: Disables stack canaries
# -z execstack: Makes the stack executable
# -o stack: The final executable
gcc -m32 -fno-stack-protector -z execstack -o vul vul.c

echo "--- Setting set-uid root permissions ---"
# This makes the program run as 'root'
sudo chown root stack
sudo chmod 4755 stack

echo "--- Compiling debug version (vul_dbg) ---"
# We compile a separate version with debug symbols (-g) for GDB
# We don't setuid this one, as it's just for inspection.
gcc -m32 -fno-stack-protector -z execstack -g -o vul_dbg stack.c

echo "--- Creating empty 'badfile' for GDB run ---"
touch badfile

echo "--- Setup Complete! ---"
echo "You can now run 'gdb vul_dbg' to find the offset."
echo "After, run './gen_badfile.py' and then './vul' to launch the attack."